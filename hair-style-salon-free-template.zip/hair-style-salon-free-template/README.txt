Credits :
--------- 

=> Design & developed: "WebThemez"  http://webthemez.com 
=> Icons: https://www.flaticon.com/
=> Bootstrap : http://getbootstrap.com/
=> Fontawesome : https://fortawesome.github.io/Font-Awesome/
=> Fonts : https://www.google.com/fonts
=> Images : https://unsplash.com/ , https://www.pexels.com/ and https://pixabay.com/
=> Carousel : http://owlgraphic.com/owlcarousel/
=> Illustrations: https://undraw.co/illustrations
